//
//  SelectCategory.swift
//  Finwise
//
//  Created by UTKARSH NAYAN on 02/04/24.
//

//import SwiftUI

//enum SelectCategory: String, CaseIterable {
//    case want = "Want"
//    case saving = "Saving"
//    case need = "Need"
//}

